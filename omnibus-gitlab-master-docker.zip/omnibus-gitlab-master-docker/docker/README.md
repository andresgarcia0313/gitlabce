The latest docker guide can be found here: [GitLab Docker images](/doc/docker/README.md).
